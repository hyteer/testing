# 1 "e:\\lr\\scsp_ssp_socket\\\\combined_SCSP_SSP_Socket.c"
# 1 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h" 1
 
 












 











# 103 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"








































































	

 


















 
 
 
 
 


 
 
 
 
 
 














int     lr_start_transaction   (char * transaction_name);
int lr_start_sub_transaction          (char * transaction_name, char * trans_parent);
long lr_start_transaction_instance    (char * transaction_name, long parent_handle);



int     lr_end_transaction     (char * transaction_name, int status);
int lr_end_sub_transaction            (char * transaction_name, int status);
int lr_end_transaction_instance       (long transaction, int status);


 
typedef char* lr_uuid_t;
 



lr_uuid_t lr_generate_uuid();

 


int lr_generate_uuid_free(lr_uuid_t uuid);

 



int lr_generate_uuid_on_buf(lr_uuid_t buf);

   
# 263 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
int lr_start_distributed_transaction  (char * transaction_name, lr_uuid_t correlator, long timeout  );

   







int lr_end_distributed_transaction  (lr_uuid_t correlator, int status);


double lr_stop_transaction            (char * transaction_name);
double lr_stop_transaction_instance   (long parent_handle);


void lr_resume_transaction           (char * trans_name);
void lr_resume_transaction_instance  (long trans_handle);


int lr_update_transaction            (const char *trans_name);


 
void lr_wasted_time(long time);


 
int lr_set_transaction(const char *name, double duration, int status);
 
long lr_set_transaction_instance(const char *name, double duration, int status, long parent_handle);


int   lr_user_data_point                      (char *, double);
long lr_user_data_point_instance                   (char *, double, long);
 



int lr_user_data_point_ex(const char *dp_name, double value, int log_flag);
long lr_user_data_point_instance_ex(const char *dp_name, double value, long parent_handle, int log_flag);


int lr_transaction_add_info      (const char *trans_name, char *info);
int lr_transaction_instance_add_info   (long trans_handle, char *info);
int lr_dpoint_add_info           (const char *dpoint_name, char *info);
int lr_dpoint_instance_add_info        (long dpoint_handle, char *info);


double lr_get_transaction_duration       (char * trans_name);
double lr_get_trans_instance_duration    (long trans_handle);
double lr_get_transaction_think_time     (char * trans_name);
double lr_get_trans_instance_think_time  (long trans_handle);
double lr_get_transaction_wasted_time    (char * trans_name);
double lr_get_trans_instance_wasted_time (long trans_handle);
int    lr_get_transaction_status		 (char * trans_name);
int	   lr_get_trans_instance_status		 (long trans_handle);

 



int lr_set_transaction_status(int status);

 



int lr_set_transaction_status_by_name(int status, const char *trans_name);
int lr_set_transaction_instance_status(int status, long trans_handle);


typedef void* merc_timer_handle_t;
 

merc_timer_handle_t lr_start_timer();
double lr_end_timer(merc_timer_handle_t timer_handle);


 
 
 
 
 
 











 



int   lr_rendezvous  (char * rendezvous_name);
 




int   lr_rendezvous_ex (char * rendezvous_name);



 
 
 
 
 
char *lr_get_vuser_ip (void);
void   lr_whoami (int *vuser_id, char ** sgroup, int *scid);
char *	  lr_get_host_name (void);
char *	  lr_get_master_host_name (void);

 
long     lr_get_attrib_long	(char * attr_name);
char *   lr_get_attrib_string	(char * attr_name);
double   lr_get_attrib_double      (char * attr_name);

char * lr_paramarr_idx(const char * paramArrayName, unsigned int index);
char * lr_paramarr_random(const char * paramArrayName);
int    lr_paramarr_len(const char * paramArrayName);

int	lr_param_unique(const char * paramName);
int lr_param_sprintf(const char * paramName, const char * format, ...);


 
 
static void *ci_this_context = 0;






 








void lr_continue_on_error (int lr_continue);
char *   lr_decrypt (const char *EncodedString);


 
 
 
 
 
 



 







 















void   lr_abort (void);
void lr_exit(int exit_option, int exit_status);
void lr_abort_ex (unsigned long flags);

void   lr_peek_events (void);


 
 
 
 
 


void   lr_think_time (double secs);

 


void lr_force_think_time (double secs);


 
 
 
 
 



















int   lr_msg (char * fmt, ...);
int   lr_debug_message (unsigned int msg_class,
									    char * format,
										...);
# 502 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
void   lr_new_prefix (int type,
                                 char * filename,
                                 int line);
# 505 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
int   lr_log_message (char * fmt, ...);
int   lr_message (char * fmt, ...);
int   lr_error_message (char * fmt, ...);
int   lr_output_message (char * fmt, ...);
int   lr_vuser_status_message (char * fmt, ...);
int   lr_error_message_without_fileline (char * fmt, ...);
int   lr_fail_trans_with_error (char * fmt, ...);

 
 
 
 
 
# 528 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"

 
 
 
 
 





int   lr_next_row ( char * table);
int lr_advance_param ( char * param);



														  
														  

														  
														  

													      
 


char *   lr_eval_string (char * str);
int   lr_eval_string_ext (const char *in_str,
                                     unsigned long const in_len,
                                     char ** const out_str,
                                     unsigned long * const out_len,
                                     unsigned long const options,
                                     const char *file,
								     long const line);
# 562 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
void   lr_eval_string_ext_free (char * * pstr);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
int lr_param_increment (char * dst_name,
                              char * src_name);
# 585 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"













											  
											  

											  
											  
											  

int	  lr_save_var (char *              param_val,
							  unsigned long const param_val_len,
							  unsigned long const options,
							  char *			  param_name);
# 609 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
int   lr_save_string (const char * param_val, const char * param_name);
int   lr_free_parameter (const char * param_name);
int   lr_save_int (const int param_val, const char * param_name);


 
 
 
 
 
 
# 676 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
void   lr_save_datetime (const char *format, int offset, const char *name);









 











 
 
 
 
 






 



char * lr_error_context_get_entry (char * key);

 



long   lr_error_context_get_error_id (void);


 
 
 

int lr_table_get_rows_num (char * param_name);

int lr_table_get_cols_num (char * param_name);

char * lr_table_get_cell_by_col_index (char * param_name, int row, int col);

char * lr_table_get_cell_by_col_name (char * param_name, int row, const char* col_name);

int lr_table_get_column_name_by_index (char * param_name, int col, 
											char * * const col_name,
											int * col_name_len);
# 737 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"

int lr_table_get_column_name_by_index_free (char * col_name);


 
 
 
 
 
 
 
 

 
 
 
 
 
 
int   lr_param_substit (char * file,
                                   int const line,
                                   char * in_str,
                                   int const in_len,
                                   char * * const out_str,
                                   int * const out_len);
# 762 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
void   lr_param_substit_free (char * * pstr);


 
# 774 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"





char *   lrfnc_eval_string (char * str,
                                      char * file_name,
                                      long const line_num);
# 782 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"


int   lrfnc_save_string ( const char * param_val,
                                     const char * param_name,
                                     const char * file_name,
                                     long const line_num);
# 788 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"

int   lrfnc_free_parameter (const char * param_name );

int lr_save_searched_string(char *buffer, long buf_size, unsigned int occurrence,
			    char *search_string, int offset, unsigned int param_val_len, 
			    char *param_name);

 
char *   lr_string (char * str);

 
# 859 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"

int   lr_save_value (char * param_val,
                                unsigned long const param_val_len,
                                unsigned long const options,
                                char * param_name,
                                char * file_name,
                                long const line_num);
# 866 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"


 
 
 
 
 











int   lr_printf (char * fmt, ...);
 
int   lr_set_debug_message (unsigned int msg_class,
                                       unsigned int swtch);
# 888 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
unsigned int   lr_get_debug_message (void);


 
 
 
 
 

void   lr_double_think_time ( double secs);
void   lr_usleep (long);


 
 
 
 
 
 




int *   lr_localtime (long offset);


int   lr_send_port (long port);


# 964 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"



struct _lr_declare_identifier{
	char signature[24];
	char value[128];
};

int   lr_pt_abort (void);

void vuser_declaration (void);






# 993 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"


# 1005 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
















 
 
 
 
 







int    _lr_declare_transaction   (char * transaction_name);


 
 
 
 
 







int   _lr_declare_rendezvous  (char * rendezvous_name);

 
 
 
 
 

 
int lr_enable_ip_spoofing();
int lr_disable_ip_spoofing();


 




int lr_convert_string_encoding(char *sourceString, char *fromEncoding, char *toEncoding, char *paramName);





 
 

















# 1 "e:\\lr\\scsp_ssp_socket\\\\combined_SCSP_SSP_Socket.c" 2

# 1 "vuser_init.c" 1
 





# 1 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrs.h" 1
 



 
# 1 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrs_err.h" 1
 






 
























 




 





 

 







 








































 










# 6 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrs.h" 2


































































































 
 




 




 
enum{
	LRS_NO_DELAY
};

 
enum{
	LOCAL_ADDRESS,
	LOCAL_HOSTNAME,
	LOCAL_PORT,
	REMOTE_ADDRESS,
	REMOTE_HOSTNAME,
	REMOTE_PORT
};

 
enum{
	Mismatch,
	EndMarker
};
 
enum{
	MISMATCH_SIZE,
	MISMATCH_CONTENT
};
 
enum{
	EndMarker_None,
	StringTerminator,
	BinaryStringTerminator,
	RecordingSize
};

 
enum{
	RecieveOption_None = 0,
	NoOption = 0,
	OffsetSize = 1,
	LeftRightBoundaries = 2,
	LeftBoundarySize = 3
};


 
int		LrsStartup(int ver_info);
int		LrsCleanup(void);
int		LrsCreateSocket(char *s_desc, char *s_type, ...);
int		LrsAcceptConnection(char *old_s_desc, char *new_s_desc);
int		LrsCloseSocket(char	*s_desc);
int		LrsDisableSocket(char *s_desc, int operation_to_disable);
int		LrsSend(char *s_desc, char *buf_desc, ...);
int		LrsLengthSend(char *s_desc, char	*buf_desc, int send_option, ...);
int		LrsSetSendBuffer(char *s_desc, char *buffer, int size);
int		LrsReceive(char	*s_desc, char *buf_desc, ...);
int		LrsReceiveEx(char *s_desc, char	*buf_desc, ...);
int		LrsLengthReceive(char *s_desc, char	*buf_desc, int receive_option, ...);
int		LrsSetReceiveOption(int option,	int value, ...);
int		LrsGetSocketHandler(char *s_desc);
int		LrsSetSocketHandler(char *s_desc,int s_handler);
int		LrsGetLastReceivedBuffer(char *s_desc, char **actual_buf, int *actual_bytes);
char*	LrsGetReceivedBuffer(char* s_desc, int sub_buf_offset, int	sub_buf_len, char*	encoding);
int		LrsGetLastReceivedBufferSize(char*	s_desc);
int		LrsGetBufferByName(char	*buf_desc, char	**actual_buf, int *actual_bytes);
char*	LrsGetStaticBuffer(char	*s_desc,char* buf_desc,int sub_buf_offset,int sub_buf_len,char* encoding);
int		LrsSaveParam(char* s_desc, char* buf_desc, char* param_name, int offset, int param_len);
int		LrsSaveParamEx(char* s_desc, char* whence, char* buf_desc, int offset, int param_len, char*	encoding, char*	param_name);
int		LrsSaveSearchedString(char*	s_desc,	char* buf_desc, char* param_name, char*	left_boundary, char* right_boundary,int ordinal, int offset, int param_len);
int		LrsFreeBuffer(char*	buffer);
void	LrsSetSendTimeout(long	tv_sec, long tv_usec);
void	LrsSetRecvTimeout(long	tv_sec,long	tv_usec);
void	LrsSetRecvTimeout2(long	tv_sec,long	tv_usec);
void	LrsSetAcceptTimeout(long tv_sec, long tv_usec);
void	LrsSetConnectTimeout(long	tv_sec,long	tv_usec);
char*	LrsEbcdicToAscii(char* s_desc, char* buf, long buf_length);
char*	LrsAsciiToEbcdic(char* s_desc, char* buf, long buf_length);
char*	LrsDecimalToHexString(char*	s_desc,	char* buf, long buf_length);
int		LrsHexStringToInt(char*	buf, long buf_length, int* mpiOutput);
char*	LrsGetUserBuffer(char* s_desc);
long	LrsGetUserBufferSize(char* s_desc);
int		LrsSetSocketOptions(char	*s_desc, int option, char *option_val);
char*	LrsGetSocketAttrib(char *s_desc, int attrib);
int		LrsExcludeSocket(char* s_desc);



# 7 "vuser_init.c" 2


 
char * ActualBuffer="";
 
int numberOfResponse = -1;
 
int rc = 0;
 
int msgOk=-1;
 
char * position="";
 
char * passMsg="SUCCESS";
char * payType="WXPAY";

char * myfee = "<fee>";


vuser_init()
{
    LrsStartup(257);

     
	 




	lr_start_transaction("SPP����");

	 
	rc = LrsCreateSocket("socket0", "TCP", "RemoteHost=10.100.100.88:13480",  "0");
	if (rc==0){
	 
	lr_output_message("��Socket was successfully created ��");
	}
	else{
	lr_output_message("��An error occurred while creating the socket, Error Code: %d��", rc);
	}
	 


	 


	 
	lr_think_time(46);

	LrsSend("socket0", "buf0", "0");
	LrsSetReceiveOption(EndMarker, StringTerminator , "\r\n");	 

	LrsReceive("socket0", "buf1", "0");


	 

     
	LrsGetLastReceivedBuffer("socket0",&ActualBuffer,&numberOfResponse);
	 
	position = (char *)strstr(ActualBuffer, passMsg);
	 
	msgOk = (int)(position - ActualBuffer + 1);
	lr_output_message("��MsgOk Code: %d��", msgOk);

    if(msgOk>0){
	lr_end_transaction("SPP����", 0);
	lr_output_message("������������%s",ActualBuffer);
	}
	else{
	lr_end_transaction("SPP����", 1);
	lr_error_message("������������%s",ActualBuffer);
	}

	 
	lr_output_message("��Fee: %s��", lr_eval_string("<fee>"));

	 
    
    return 0;
}

# 2 "e:\\lr\\scsp_ssp_socket\\\\combined_SCSP_SSP_Socket.c" 2

# 1 "Action.c" 1
 






# 1 "md5.h" 1





typedef unsigned long uint32;

struct MD5Context {
        uint32 buf[4];
        uint32 bits[2];
        unsigned char in[64];
};
extern void MD5Init();
extern void MD5Update();
extern void MD5Final();
extern void MD5Transform();
typedef struct MD5Context MD5_CTX;









# 37 "md5.h"

void MD5Init(ctx)struct MD5Context *ctx;
{
    ctx->buf[0] = 0x67452301;
    ctx->buf[1] = 0xefcdab89;
    ctx->buf[2] = 0x98badcfe;
    ctx->buf[3] = 0x10325476;
    ctx->bits[0] = 0;
    ctx->bits[1] = 0;
}
void MD5Update(ctx, buf, len) struct MD5Context *ctx; unsigned char *buf; unsigned len;
{
    uint32 t;
    t = ctx->bits[0];
    if ((ctx->bits[0] = t + ((uint32) len << 3)) < t)
    ctx->bits[1]++;
    ctx->bits[1] += len >> 29;
    t = (t >> 3) & 0x3f;
    if (t) {
    unsigned char *p = (unsigned char *) ctx->in + t;
    t = 64 - t;
    if (len < t) {
        memcpy(p, buf, len);
        return;
    }
    memcpy(p, buf, t);
     ;
    MD5Transform(ctx->buf, (uint32 *) ctx->in);
    buf += t;
    len -= t;
    }
    while (len >= 64) {
    memcpy(ctx->in, buf, 64);
     ;
    MD5Transform(ctx->buf, (uint32 *) ctx->in);
    buf += 64;
    len -= 64;
    }
    memcpy(ctx->in, buf, len);
}
void MD5Final(digest, ctx)
    unsigned char digest[16]; struct MD5Context *ctx;
{
    unsigned count;
    unsigned char *p;
    count = (ctx->bits[0] >> 3) & 0x3F;
    p = ctx->in + count;
    *p++ = 0x80;
    count = 64 - 1 - count;
    if (count < 8) {
    memset(p, 0, count);
     ;
    MD5Transform(ctx->buf, (uint32 *) ctx->in);
    memset(ctx->in, 0, 56);
    } else {
    memset(p, 0, count - 8);
    }
     ;
    ((uint32 *) ctx->in)[14] = ctx->bits[0];
    ((uint32 *) ctx->in)[15] = ctx->bits[1];
    MD5Transform(ctx->buf, (uint32 *) ctx->in);
     ;
    memcpy(digest, ctx->buf, 16);
    memset(ctx, 0, sizeof(ctx));
}






void MD5Transform(buf, in)
    uint32 buf[4]; uint32 in[16];
{
    register uint32 a, b, c, d;
    a = buf[0];
    b = buf[1];
    c = buf[2];
    d = buf[3];
    (  a += (  d ^ ( b & (  c ^   d))) +  in[0] + 0xd76aa478,   a =  a<< 7 |  a>>(32- 7),   a +=  b );
    (  d += (  c ^ ( a & (  b ^   c))) +  in[1] + 0xe8c7b756,   d =  d<< 12 |  d>>(32- 12),   d +=  a );
    (  c += (  b ^ ( d & (  a ^   b))) +  in[2] + 0x242070db,   c =  c<< 17 |  c>>(32- 17),   c +=  d );
    (  b += (  a ^ ( c & (  d ^   a))) +  in[3] + 0xc1bdceee,   b =  b<< 22 |  b>>(32- 22),   b +=  c );
    (  a += (  d ^ ( b & (  c ^   d))) +  in[4] + 0xf57c0faf,   a =  a<< 7 |  a>>(32- 7),   a +=  b );
    (  d += (  c ^ ( a & (  b ^   c))) +  in[5] + 0x4787c62a,   d =  d<< 12 |  d>>(32- 12),   d +=  a );
    (  c += (  b ^ ( d & (  a ^   b))) +  in[6] + 0xa8304613,   c =  c<< 17 |  c>>(32- 17),   c +=  d );
    (  b += (  a ^ ( c & (  d ^   a))) +  in[7] + 0xfd469501,   b =  b<< 22 |  b>>(32- 22),   b +=  c );
    (  a += (  d ^ ( b & (  c ^   d))) +  in[8] + 0x698098d8,   a =  a<< 7 |  a>>(32- 7),   a +=  b );
    (  d += (  c ^ ( a & (  b ^   c))) +  in[9] + 0x8b44f7af,   d =  d<< 12 |  d>>(32- 12),   d +=  a );
    (  c += (  b ^ ( d & (  a ^   b))) +  in[10] + 0xffff5bb1,   c =  c<< 17 |  c>>(32- 17),   c +=  d );
    (  b += (  a ^ ( c & (  d ^   a))) +  in[11] + 0x895cd7be,   b =  b<< 22 |  b>>(32- 22),   b +=  c );
    (  a += (  d ^ ( b & (  c ^   d))) +  in[12] + 0x6b901122,   a =  a<< 7 |  a>>(32- 7),   a +=  b );
    (  d += (  c ^ ( a & (  b ^   c))) +  in[13] + 0xfd987193,   d =  d<< 12 |  d>>(32- 12),   d +=  a );
    (  c += (  b ^ ( d & (  a ^   b))) +  in[14] + 0xa679438e,   c =  c<< 17 |  c>>(32- 17),   c +=  d );
    (  b += (  a ^ ( c & (  d ^   a))) +  in[15] + 0x49b40821,   b =  b<< 22 |  b>>(32- 22),   b +=  c );
    (  a += (   c ^ (  d & (  b ^    c))) +  in[1] + 0xf61e2562,   a =  a<< 5 |  a>>(32- 5),   a +=  b );
    (  d += (   b ^ (  c & (  a ^    b))) +  in[6] + 0xc040b340,   d =  d<< 9 |  d>>(32- 9),   d +=  a );
    (  c += (   a ^ (  b & (  d ^    a))) +  in[11] + 0x265e5a51,   c =  c<< 14 |  c>>(32- 14),   c +=  d );
    (  b += (   d ^ (  a & (  c ^    d))) +  in[0] + 0xe9b6c7aa,   b =  b<< 20 |  b>>(32- 20),   b +=  c );
    (  a += (   c ^ (  d & (  b ^    c))) +  in[5] + 0xd62f105d,   a =  a<< 5 |  a>>(32- 5),   a +=  b );
    (  d += (   b ^ (  c & (  a ^    b))) +  in[10] + 0x02441453,   d =  d<< 9 |  d>>(32- 9),   d +=  a );
    (  c += (   a ^ (  b & (  d ^    a))) +  in[15] + 0xd8a1e681,   c =  c<< 14 |  c>>(32- 14),   c +=  d );
    (  b += (   d ^ (  a & (  c ^    d))) +  in[4] + 0xe7d3fbc8,   b =  b<< 20 |  b>>(32- 20),   b +=  c );
    (  a += (   c ^ (  d & (  b ^    c))) +  in[9] + 0x21e1cde6,   a =  a<< 5 |  a>>(32- 5),   a +=  b );
    (  d += (   b ^ (  c & (  a ^    b))) +  in[14] + 0xc33707d6,   d =  d<< 9 |  d>>(32- 9),   d +=  a );
    (  c += (   a ^ (  b & (  d ^    a))) +  in[3] + 0xf4d50d87,   c =  c<< 14 |  c>>(32- 14),   c +=  d );
    (  b += (   d ^ (  a & (  c ^    d))) +  in[8] + 0x455a14ed,   b =  b<< 20 |  b>>(32- 20),   b +=  c );
    (  a += (   c ^ (  d & (  b ^    c))) +  in[13] + 0xa9e3e905,   a =  a<< 5 |  a>>(32- 5),   a +=  b );
    (  d += (   b ^ (  c & (  a ^    b))) +  in[2] + 0xfcefa3f8,   d =  d<< 9 |  d>>(32- 9),   d +=  a );
    (  c += (   a ^ (  b & (  d ^    a))) +  in[7] + 0x676f02d9,   c =  c<< 14 |  c>>(32- 14),   c +=  d );
    (  b += (   d ^ (  a & (  c ^    d))) +  in[12] + 0x8d2a4c8a,   b =  b<< 20 |  b>>(32- 20),   b +=  c );
    (  a += ( b ^   c ^   d) +  in[5] + 0xfffa3942,   a =  a<< 4 |  a>>(32- 4),   a +=  b );
    (  d += ( a ^   b ^   c) +  in[8] + 0x8771f681,   d =  d<< 11 |  d>>(32- 11),   d +=  a );
    (  c += ( d ^   a ^   b) +  in[11] + 0x6d9d6122,   c =  c<< 16 |  c>>(32- 16),   c +=  d );
    (  b += ( c ^   d ^   a) +  in[14] + 0xfde5380c,   b =  b<< 23 |  b>>(32- 23),   b +=  c );
    (  a += ( b ^   c ^   d) +  in[1] + 0xa4beea44,   a =  a<< 4 |  a>>(32- 4),   a +=  b );
    (  d += ( a ^   b ^   c) +  in[4] + 0x4bdecfa9,   d =  d<< 11 |  d>>(32- 11),   d +=  a );
    (  c += ( d ^   a ^   b) +  in[7] + 0xf6bb4b60,   c =  c<< 16 |  c>>(32- 16),   c +=  d );
    (  b += ( c ^   d ^   a) +  in[10] + 0xbebfbc70,   b =  b<< 23 |  b>>(32- 23),   b +=  c );
    (  a += ( b ^   c ^   d) +  in[13] + 0x289b7ec6,   a =  a<< 4 |  a>>(32- 4),   a +=  b );
    (  d += ( a ^   b ^   c) +  in[0] + 0xeaa127fa,   d =  d<< 11 |  d>>(32- 11),   d +=  a );
    (  c += ( d ^   a ^   b) +  in[3] + 0xd4ef3085,   c =  c<< 16 |  c>>(32- 16),   c +=  d );
    (  b += ( c ^   d ^   a) +  in[6] + 0x04881d05,   b =  b<< 23 |  b>>(32- 23),   b +=  c );
    (  a += ( b ^   c ^   d) +  in[9] + 0xd9d4d039,   a =  a<< 4 |  a>>(32- 4),   a +=  b );
    (  d += ( a ^   b ^   c) +  in[12] + 0xe6db99e5,   d =  d<< 11 |  d>>(32- 11),   d +=  a );
    (  c += ( d ^   a ^   b) +  in[15] + 0x1fa27cf8,   c =  c<< 16 |  c>>(32- 16),   c +=  d );
    (  b += ( c ^   d ^   a) +  in[2] + 0xc4ac5665,   b =  b<< 23 |  b>>(32- 23),   b +=  c );
    (  a += (  c ^ ( b | ~  d)) +  in[0] + 0xf4292244,   a =  a<< 6 |  a>>(32- 6),   a +=  b );
    (  d += (  b ^ ( a | ~  c)) +  in[7] + 0x432aff97,   d =  d<< 10 |  d>>(32- 10),   d +=  a );
    (  c += (  a ^ ( d | ~  b)) +  in[14] + 0xab9423a7,   c =  c<< 15 |  c>>(32- 15),   c +=  d );
    (  b += (  d ^ ( c | ~  a)) +  in[5] + 0xfc93a039,   b =  b<< 21 |  b>>(32- 21),   b +=  c );
    (  a += (  c ^ ( b | ~  d)) +  in[12] + 0x655b59c3,   a =  a<< 6 |  a>>(32- 6),   a +=  b );
    (  d += (  b ^ ( a | ~  c)) +  in[3] + 0x8f0ccc92,   d =  d<< 10 |  d>>(32- 10),   d +=  a );
    (  c += (  a ^ ( d | ~  b)) +  in[10] + 0xffeff47d,   c =  c<< 15 |  c>>(32- 15),   c +=  d );
    (  b += (  d ^ ( c | ~  a)) +  in[1] + 0x85845dd1,   b =  b<< 21 |  b>>(32- 21),   b +=  c );
    (  a += (  c ^ ( b | ~  d)) +  in[8] + 0x6fa87e4f,   a =  a<< 6 |  a>>(32- 6),   a +=  b );
    (  d += (  b ^ ( a | ~  c)) +  in[15] + 0xfe2ce6e0,   d =  d<< 10 |  d>>(32- 10),   d +=  a );
    (  c += (  a ^ ( d | ~  b)) +  in[6] + 0xa3014314,   c =  c<< 15 |  c>>(32- 15),   c +=  d );
    (  b += (  d ^ ( c | ~  a)) +  in[13] + 0x4e0811a1,   b =  b<< 21 |  b>>(32- 21),   b +=  c );
    (  a += (  c ^ ( b | ~  d)) +  in[4] + 0xf7537e82,   a =  a<< 6 |  a>>(32- 6),   a +=  b );
    (  d += (  b ^ ( a | ~  c)) +  in[11] + 0xbd3af235,   d =  d<< 10 |  d>>(32- 10),   d +=  a );
    (  c += (  a ^ ( d | ~  b)) +  in[2] + 0x2ad7d2bb,   c =  c<< 15 |  c>>(32- 15),   c +=  d );
    (  b += (  d ^ ( c | ~  a)) +  in[9] + 0xeb86d391,   b =  b<< 21 |  b>>(32- 21),   b +=  c );
    buf[0] += a;
    buf[1] += b;
    buf[2] += c;
    buf[3] += d;
}
char* CMd5(const char* s)
{
     struct MD5Context md5c;
     unsigned char ss[16];
     char subStr[3],resStr[33];
     int i;
     MD5Init( &md5c );
     MD5Update( &md5c, s, strlen(s) );
     MD5Final( ss, &md5c );
     strcpy(resStr,"");
     for( i=0; i<16; i++ )
     {
         sprintf(subStr, "%02x", ss[i] );
         itoa(ss[i],subStr,16);
         if (strlen(subStr)==1) {
             strcat(resStr,"0");
         }
         strcat(resStr,subStr);
     }
     strcat(resStr,"\0");
     return resStr;
}


# 8 "Action.c" 2



Action()
{

	 
# 37 "Action.c"


	 
# 71 "Action.c"
    
	char s[200]="test";
    char sign[32];
    strcat(sign,CMd5(s));
    lr_output_message("%s",sign);

    lr_output_message("��Fee: %s��", lr_eval_string("<fee>"));
	lr_output_message("��AllPack: %s��", lr_eval_string("buf0"));

	 


     
	

    return 0;
}

# 3 "e:\\lr\\scsp_ssp_socket\\\\combined_SCSP_SSP_Socket.c" 2

# 1 "vuser_end.c" 1
 








vuser_end()
{
    LrsCleanup();

    return 0;
}

# 4 "e:\\lr\\scsp_ssp_socket\\\\combined_SCSP_SSP_Socket.c" 2

