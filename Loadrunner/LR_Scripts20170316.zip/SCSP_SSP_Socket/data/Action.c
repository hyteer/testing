/*********************************************************************
 * Created by Mercury Interactive Windows Sockets Recorder
 *
 * Created on: Thu Mar 16 10:31:46
 *********************************************************************/

#include "lrs.h"


Action()
{
    return 0;
}

