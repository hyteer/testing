/*********************************************************************
 * Created by Mercury Interactive Windows Sockets Recorder
 *
 * Created on: Thu Mar 16 10:31:46
 *********************************************************************/

#include "lrs.h"


vuser_init()
{
    lrs_startup(257);

    lrs_create_socket("socket0", "TCP", "RemoteHost=10.100.100.88:13480",  LrsLastArg);

    lr_think_time(46);

    lrs_send("socket0", "buf0", LrsLastArg);

    lrs_receive("socket0", "buf1", LrsLastArg);

    return 0;
}

