Action()
{

	int itera_num,rand_num,irand_num,i;  
	//char i_name[24]="";  
	//char StrTable[]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";  
	//char NumTable[]="0123456789";
	char out_trade_no_pre[10]="10002000";
	char * out_trade_no="";
	char *tmp="hello";

	char StrTable[]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"; 
	char NumTable[]="1234567890";
	char i_name[24]=""; 
	char i_num[12]=""; 
	char i_data2[24]=""; 


	/************** Random Num/String **************/

	for (i=0;i<=8;i++){  
		rand_num=rand()%62;  
		strncat(i_name,StrTable+rand_num,1);  
	}  
	lr_save_string(i_name,"i_name_value");  
	lr_log_message("i_name== %s", i_name); 

	for (i=0;i<=12;i++){  
		rand_num=rand()%62;  
		strncat(i_name,StrTable+rand_num,1);  
	}



	itera_num=rand()%24; 
	for (i=0;i<=12;i++){
		irand_num=rand()%62; 
		strncat(i_name,StrTable+irand_num,1);
	}
	lr_save_string(i_name,"i_name_value");
	lr_log_message("��i_name2��: %s", i_name);

	//itera_num=rand()%10; 
	for(i=0;i<=11;i++){
		irand_num=rand()%10; 
		strncat(i_num,NumTable+irand_num,1);
	}

	lr_save_string(i_num,"i_num_value");
	lr_log_message("��i_num��: %s", i_num);



	lr_save_string("hello world","param");
	lr_output_message(lr_eval_string("{param}"));



	/**************** Save To Params ***************/


	lr_output_message("��ParamNum����%s",lr_eval_string("{i_num_value}"));

	lr_output_message("LR_Param:%s", lr_eval_string("{NewParam}"));


	return 0;
}
