#include "lrs.h"


vuser_end()
{
    lrs_cleanup();

    return 0;
}

