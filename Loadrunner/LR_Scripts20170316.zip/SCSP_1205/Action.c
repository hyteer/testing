Action()
{

		unsigned long length = 0;
		char* tmp = 0;


		web_set_proxy("10.20.50.72:8888");

		web_reg_save_param_ex(
		"ParamName=Body", 
		"LB=", 
		"RB=",                  
		SEARCH_FILTERS, 
		"Scope=Body",
		"RelFrameID=1",
		LAST);


        web_add_header("Content-Type","text/html; charset=utf-8");
        web_add_header("Cache-Control","no-cache");
        web_custom_request("AgentServer",
        "URL=http://10.20.60.76:16180/unifiedorder",
        "Method=POST",
        "Resource=0",
        "Mode=HTML",
        "EncType=text/xml; charset=utf-8",
        "Body=<xml>1</xml>",
                LAST);
		

		lr_eval_string_ext("{Body}", strlen("{Body}"), &tmp, &length, 0, 0, -1);
		lr_output("body length is %d", length);
		lr_output("��Response��: %d", tmp);
		lr_eval_string_ext_free(&tmp);


	return 0;
}
