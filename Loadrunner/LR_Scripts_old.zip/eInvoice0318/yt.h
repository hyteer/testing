
char *yt="YT test";
char *xml_res;
char *xml_test_res;
int xml_test;
char *xml_test2;
char *xml_input;



//int size;

