
char *yt="YT test";
char *xml_res;
char *xml_input;

int size;


//value2="YT test";
