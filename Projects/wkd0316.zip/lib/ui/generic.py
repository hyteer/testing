# coding: utf-8
import sys,time,random,re
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from .conf import *

class Generic(object):

    def __init__(self,conf):
        self.conf = conf

    def input(self,driver,xpath,value,param=None):
        '''
        输入操作
        '''
        if param:
            xpath = xpath % param
        element = WebDriverWait(driver, TIME_OUT).until(EC.visibility_of_element_located((By.XPATH, xpath)))
        time.sleep(1)
        element.clear()
        time.sleep(0.5)
        element.send_keys(value)
        time.sleep(1)

    def click(self,driver,xpath,param=None):
        '''
        点击操作
        '''
        #element = WebDriverWait(driver, 10).until(lambda x: x.find_element_by_xpath(xpath=xpath))
        if param:
            xpath = xpath % param
        element = WebDriverWait(driver, TIME_OUT).until(EC.presence_of_element_located((By.XPATH, xpath)))
        time.sleep(1)
        element.click()
        time.sleep(0.8)

    def click_one_from_list(self,driver,xpath,index=None,param=None):
        '''
        从元素组中点击一个
        '''
        if param:
            xpath = xpath % param
        els = WebDriverWait(driver, TIME_OUT).until(EC.presence_of_all_elements_located((By.XPATH,xpath)))
        if index == None:
            index = random.randrange(0,len(els))
        time.sleep(1)
        els[index].click()
        time.sleep(1)

    def choose(self,driver,xpath,index=None,param=None):
        '''
        从元素组中选择一个
        '''
        if param:
            xpath = xpath % param
        els = WebDriverWait(driver, TIME_OUT).until(EC.presence_of_all_elements_located((By.XPATH,xpath)))
        if index == None:
            index = random.randrange(0,len(els))
        time.sleep(1)
        els[index].click()
        time.sleep(1)


    def get_text(self,driver,xpath,param=None):
        '''
        获取元素文本值
        '''
        if param:
            xpath = xpath % param
        text = WebDriverWait(driver, TIME_OUT).until(EC.presence_of_element_located((By.XPATH, xpath))).text
        return text

    def get_value(self,driver,xpath,param=None):
        '''
        获取元素value
        '''
        if param:
            xpath = xpath % param
        value = WebDriverWait(driver, TIME_OUT).until(EC.presence_of_element_located((By.XPATH, xpath))).get_attribute('value')
        return value

    def get_element(self,driver,xpath,param=None):
        '''
        获取元素
        '''
        if param:
            xpath = xpath % param
        el = WebDriverWait(driver, TIME_OUT).until(EC.presence_of_element_located((By.XPATH, xpath)))
        return el

    def should_contains_element(self,driver,xpath,param=None):
        '''
        判断页面中存在某元素
        '''
        if param:
            xpath = xpath % param
        el = WebDriverWait(driver, TIME_OUT).until(EC.presence_of_element_located((By.XPATH, xpath)))

    def should_be_visible(self,driver,xpath,param=None):
        '''
        判断元素可见
        '''
        if param:
            xpath = xpath % param
        el = WebDriverWait(driver, TIME_OUT).until(EC.visibility_of_element_located((By.XPATH, xpath)))

    def should_contains_text(self,driver,xpath,text,param=None):
        '''
        判断元素包含特定文字
        '''
        if param:
            xpath = xpath % param
        el = WebDriverWait(driver, TIME_OUT).until(EC.presence_of_element_located((By.XPATH, xpath)))
        match = re.findall(text,el.text)
        assert len(match) > 0
        return True

    def should_equals_text(self,driver,xpath,text,param=None):
        '''
        判断元素text等于特定文字
        '''
        if param:
            xpath = xpath % param
        el = WebDriverWait(driver, TIME_OUT).until(EC.presence_of_element_located((By.XPATH, xpath)))
        assert text == el.text
        return True


