# coding: utf-8


USERHOME = {
    '红包': '''//a[@href="../user/redpack?is_use=2"]''',
    '卡券': '''//a[@href="../card-coupons/list"]''',
    '积分': '''//a[@href="../member/member-point"]''',
    #
    '待付款': '''//a[@href="../order/list?_status=1"]''',
    '待发货': '''//a[@href="../order/list?_status=2"]''',
    '待收货': '''//a[@href="../order/list?_status=3"]''',
    '已完成': '''//a[@href="../order/list?_status=4"]''',
    '售后': '''//a[@href="../order/list?_status=5"]''',
    '会员卡': '''//a[@ng-click="getMember()"]''',
    #
    '我的拼团': '''//a[@href="../together-buy/my-queue"]''',
    '我的活动': '''//a[@href="../user/activity"]''',
    '我的地址': {
        '我的地址': '''//a[@href="../user/address-list"]''',
        '新增收货地址': '''//a[@href="../user/address-add"]''',
    },
    '我的地址2': '''//a[@href="../user/address-list"]''',
    '我的预约': '''//a[@href="../user/reserve"]''',
    '兑奖二维码': '''//a[@href="../user/qrcode"]''',
    '我的资产': '''//a[@href="../user/property"]''',
    # 卡券

    '卡券名称': '//h3[@ng-bind="list.cardTypeInfo.title"]',
    '卡券类型': 'ng-bind="cardDitail(list.cardTypeInfo.wx_card_type, list.cardTypeInfo.cardTypeInfoProduct)"]',
    '商户名称': '//span[@ng-bind="list.cardTypeInfo.brand_name"]',
    '使用状态': '//i[@ng-bind="timeFun(list.time_status)"]',
    '有效期': '//span[@ng-bind="dataType(list)"]',
    # 我的资产
}

MEMBER = {
    ''
}

ADDRESS = {
    '我的地址': '''//a[@href="../user/address-list"]''',
    '新增收货地址': '''//a[@href="../user/address-add"]''',
    '收货人': '''//input[@ng-model="model.consignee"]''',
    '手机号码': '''//input[@ng-model="model.tel"]''',
    '详细地址': '''//input[@ng-model="model.detail"]''',
    '所在地区': '''//dd[@ng-click="gotoChoose()"]''',
    '选择省': '''//li[@ng-click="clickProvince($event, $index, list)"]''',
    '选择市': '''//div[@ng-repeat="list in cityList"]''',
    '选择区': '''//a[@ng-click="chooseAddress($event, $index, list)"]''',
    '设为默认地址': '''//input[@ng-model="is_default"]''',
    '从地址列表中设为默认': '''//i[@ng-click="changeCheck($index, list)" and not(contains(@class,"checked"))]''',
    '编辑': '''//i[@ng-click="changeCheck($index, list)" and not(contains(@class,"checked"))]/ancestor::div[@class="wsh_cell"]//a[starts-with(@href,"../user/address-edit?_id=")]''',
    '删除': '''//i[@ng-click="changeCheck($index, list)" and not(contains(@class,"checked"))]/ancestor::div[@class="wsh_cell"]//a[@ng-click="delete(list.id)"]''',

}

PROPERTY = {
    '积分': '//span[@ng-bind="totalPoint"]',
    '红包': '//span[@ng-bind="redpackData"]',
    '卡券': '//span[@ng-bind="countUserCard"]',
    '标题': '//h4[@class="fl"]',
    # 积分
    '可用积分': '//span[@ng-bind="totalPoint"]',
    '操作说明': '//span[@ng-bind="list.source"]',
    '积分变动': '//span[@ng-bind="list.change"]',
    '操作时间': '''//span[@ng-bind="list.created * 1000 | date:'yyyy-MM-dd HH:mm:ss'"]''',
    # 红包
    '红包_未使用': '//span[text()="未使用"]/parent::a',
    '红包_已使用': '//span[text()="已使用"]/parent::a',
    # 卡券
    '卡券_未使用': '//span[@ng-click="getData(1,2)"]',
    '卡券_已使用': '//span[@ng-click="getData(1,3)"]',
    '卡券名称': '//h3[@ng-bind="list.cardTypeInfo.title"]',
    '卡券类型': 'ng-bind="cardDitail(list.cardTypeInfo.wx_card_type, list.cardTypeInfo.cardTypeInfoProduct)"]',
    '商户名称': '//span[@ng-bind="list.cardTypeInfo.brand_name"]',
    '使用状态': '//i[@ng-bind="timeFun(list.time_status)"]',
    '有效期': '//span[@ng-bind="dataType(list)"]',

}


