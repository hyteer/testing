# coding: utf-8
'''
Weixin UI库交互类
'''
import sys,time,random
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from ...generic import Generic
from ..actions import Action
from ...conf import *
from .property import Property
from . import locators as LC


class Main(Action):

    def __init__(self,conf):
        Action.__init__(self,conf)

    def click(self,key,param=None):
        '''
        点击
        '''
        self.G.click(self.conf.wxdriver,LC.USERHOME[key],param)

    def choose(self,key,index=None,param=None):
        '''
        选择
        '''
        self.G.choose(self.conf.wxdriver,LC.USERHOME[key],index,param)

    def click_proerty(self):
        pass
        # Todo






