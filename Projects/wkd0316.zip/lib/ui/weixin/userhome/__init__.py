'''
Weixin UI库
'''
from ..actions import Action
from .main import Main
from .address import Address
from .property import Property
from . import locators as LOCATOR


class UserHome(Action):

    def __init__(self,conf):
        Action.__init__(self,conf)
        self.main = Main(conf )
        self.address = Address(conf)
        self.property = Property(conf)
        self.LOCATOR = LOCATOR


__all__ = [
    'Action',
    'Main',
    'Address',
    'Property',
    'LOCATOR',

]
