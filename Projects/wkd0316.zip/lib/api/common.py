'''
通用API
'''
from .shop import Shop
import time
from .generic import Generic as g

class CommonApi(object):
    pass
    # Todo







