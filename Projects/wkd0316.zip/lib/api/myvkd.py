#coding:utf-8
'''
Created on 2017��1��12��

@author: binwangdai
'''

class MyVkd(object):
    '''
    微店铺模块相关接口
    '''

    def __init__(self,conf):
        self.conf = conf

    def image(self,conf,args):
        pass
        