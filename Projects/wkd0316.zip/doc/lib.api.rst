lib.api package
===============

Submodules
----------

lib.api.generic module
----------------------

.. automodule:: lib.api.generic
    :members:
    :undoc-members:
    :show-inheritance:

lib.api.market module
---------------------

.. automodule:: lib.api.market
    :members:
    :undoc-members:
    :show-inheritance:

lib.api.member module
---------------------

.. automodule:: lib.api.member
    :members:
    :undoc-members:
    :show-inheritance:

lib.api.myvkd module
--------------------

.. automodule:: lib.api.myvkd
    :members:
    :undoc-members:
    :show-inheritance:

lib.api.shop module
-------------------

.. automodule:: lib.api.shop
    :members:
    :undoc-members:
    :show-inheritance:

lib.api.terminal module
-----------------------

.. automodule:: lib.api.terminal
    :members:
    :undoc-members:
    :show-inheritance:

lib.api.weixin module
---------------------

.. automodule:: lib.api.weixin
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: lib.api
    :members:
    :undoc-members:
    :show-inheritance:
