import pytest
from _pytest.runner import runtestprotocol

import pytest
@pytest.mark.hookwrapper
def pytest_runtest_makereport(item, call):
    print("testing...")
    outcome = yield
    report = outcome.get_result()
    extra = getattr(report, 'extra', [])
    #import pdb;pdb.set_trace()
    result = []
    if report.when == "call" and report.failed:
        import pdb;pdb.set_trace()

