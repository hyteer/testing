# coding: utf-8
import time

def test_float_compare():
    x = '0.131'
    y = '0.130'
    z = x + y
    print("Z is:",z)

def test_simple_echo():
    x = 1
    y = 2
    assert x > y

def test_api_debug(conf):
    print("New SSID:", conf.SSID)

def test_yet_another():
    print("Another test:")

def test_conf_env(conf):
    print("Env:",conf.ENV)


