import requests,csv

#USER_ID = '13764549'
USER_ID = '13765196'
#URL = 'http://activity.snsshop.net/draws/371?code=7JQTEF9KAAAAP4&uid=13764549&open_id=oEXpPs-_amjonXbamo4Utlpwdzyg&sub=2&shop_id=98209'
URL_TP = 'http://activity.snsshop.net/draws/371?code=7JQTEF9KAAAAP4&uid={user_id}&open_id=oEXpPs-_amjonXbamo4Utlpwdzyg&sub=2&shop_id=98209'
URL = URL_TP.format(user_id=USER_ID)
CSV_FILE = 'F:\\Temp\\wkd_users.csv'
DEBUG_USERS = [
    13765012,
    13765196,
    13765015,
    13765191,
    13765017,
]

def req(url):
    #print("URL:",url)
    r = requests.get(url)
    #print("Code:",r.status_code)
    return r

#req(URL)

def read_csv(filename,):
    mylist = []
    with open(filename, newline='') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
        print("------Checking Users------")
        for row in spamreader:
            #print(', '.join(row))
            #print(row[0])
            url = URL_TP.format(user_id=row[0])
            r = req(url)
            print(row[0],r.status_code)
            if r.status_code == 200:
                mylist.append(row[0])
                #print(row[0])

        '''
        for user in DEBUG_USERS:
            url = URL_TP.format(user_id=str(user))
            r = req(url)
            print("Code:",r.status_code)
        '''
    print("------Valid Users------")
    for i in mylist:
        print(i)


def to_csv(fileName,datalist):
    with open(fileName, "wb") as csvFile:
        csvWriter = csv.writer(csvFile)
        for data in datalist:
            csvWriter.writerow(data)
        csvFile.close

read_csv(CSV_FILE)




