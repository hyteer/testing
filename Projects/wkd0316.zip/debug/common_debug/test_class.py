import pytest
from conftest import GFLAG
from conftest import Config


class TestOrder():

    #MyFlag = True

    @pytest.fixture(autouse=True)
    def setup(self):
        self.MyFlag = 11
        print("\nsetup...")

    def test_simple1(self):
        print("test simple1...")

    def test_simple2(self):
        print("test simple2...")

    @pytest.mark.skipif(True if Config.SSID is True else False,reason="u see this when GFLAG is True")
    def test_hook_skipif(self):
        print("RunFlag:",Config.RUN_FLAG)
        print("Config SSID:",Config.SSID)
        print("Gflag:",GFLAG)
        print("test skipif...")

    @pytest.mark.xfail(True if Config.SSID is None else False,reason="u see this when condition is True")
    def test_hook_xfail(self):
        assert Config.SSID is True
        print("Config SSID:",Config.SSID)
        print("Gflag:",GFLAG)
        print("test skipif...")

    @pytest.mark.skipif(True,reason="u see this when GFLAG is True")
    def test_hook_runflag(self):
        print("RunFlag:",Config.RUN_FLAG)



