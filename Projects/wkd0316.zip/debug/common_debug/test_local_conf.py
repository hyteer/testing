import pytest,os
from conftest import Config

GConfig = None

class TestOrder():

    #MyFlag = True
    x = 1
    y = 0

    @pytest.fixture(autouse=True)
    def setup(self,conf):
        print("OS:",os.environ["RUNFLAG"])
        self.conf = conf
        GConfig = conf
        z =self.x + 1
        self.y = self.x +1
        self.MyFlag = 11
        print("\nsetup...")

    def test_simple1(self,):
        print("test simple1...")

    def test_simple2(self):
        print("test simple2...")


    @pytest.mark.skipif(not GConfig,reason="u see this when GFLAG is True")
    def test_hook_runflag(self):
        print("Config:",dir(Config))
        print("SSID:",Config.SSID)



