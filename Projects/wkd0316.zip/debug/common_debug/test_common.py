import pytest
import os
from conftest import GFLAG

some_cmd_param = 'sfsfs'

def flag(x):
    if x:
        return True
    else:
        return False

@pytest.mark.debug
def test_temp():
    print("debug...")
    #import pdb;pdb.set_trace()

@pytest.mark.no_cycle
@pytest.mark.skipif(flag(some_cmd_param),reason="stop...")
def test_temp_debug():
    print("\ntemp debug...")
    #import pdb;pdb.set_trace()

@pytest.mark.skipif(True if some_cmd_param else False,reason="stop...")
def test_temp_debug():
    print("\ntemp debug...")

@pytest.mark.skipif(GFLAG,reason="gflag is True...")
def test_osenv():
    FLAG = os.environ["RUNFLAG"]
    print("【OS2]:",FLAG)
    print("\nTest Run_Flag:",os.environ["RUNFLAG"])