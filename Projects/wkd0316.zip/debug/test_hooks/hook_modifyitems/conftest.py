import pytest
from _pytest.runner import runtestprotocol

import pytest

@pytest.fixture(autouse=True)
def pytest_collection_modifyitems(config, items):
    #import pdb;pdb.set_trace()
    pass
