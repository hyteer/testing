import pytest
from _pytest.runner import runtestprotocol

import pytest
@pytest.mark.hookwrapper
def pytest_runtest_makereport(item, call):
    print("testing...")
    outcome = yield
    rep = outcome.get_result()
    extra = getattr(rep, 'extra', [])
    #import pdb;pdb.set_trace()
    result = []
    if rep.when == "call":

        if rep.failed:
            import pdb;pdb.set_trace()
        result = rep.outcome
        d = {'name':rep.location[2], 'result':result, 'location':rep.location[0]}
        print(d)

