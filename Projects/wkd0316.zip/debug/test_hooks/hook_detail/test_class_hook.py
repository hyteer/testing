import pytest
from selenium import webdriver

class TestOrder:
    # UI测试：订单模块
    wx = None
    FLAG = False

    @pytest.fixture(autouse=True)
    def setup(self,conf):
        self.wx = conf.ui.Weixin(conf)
        self.pd = self.wx.product
        self.od = self.wx.order
        self.conf = conf
        self.LC = self.wx.LOCATOR
        driver = webdriver.Chrome()
        self.driver = driver
        conf.COMMON.wx_login(conf,driver)
        return conf

    def test_cancel_order(self):

        self.wx.bottom_menu('我')
        self.wx.userhome.click('待付款')
        x = 1
        y = 2
        print("Test Conf...")
        assert x > y

    def test_simple_echo(conf):
        x = 1
        y = 2
        print("Test Conf...")
        assert x > y