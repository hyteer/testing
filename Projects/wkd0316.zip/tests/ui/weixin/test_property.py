import time
import pytest
from selenium import webdriver
from selenium.webdriver.common.alert import Alert


class TestProperty:
    '''UI模块测试：用户中心->我的资产'''

    AUTHOR = 'YT'
    wx = None
    FLAG = False

    @pytest.fixture(autouse=True)
    def setup(self,conf):
        self.conf = conf
        self.wx = conf.ui.Weixin(conf)
        self.LC = self.wx.LOCATOR
        driver = webdriver.Chrome()
        self.driver = driver
        conf.COMMON.wx_login(conf,driver)
        return conf

    def test_point(self):
        '''
        我的资产->积分
        '''
        driver = self.driver
        property = self.wx.userhome.property
        self.wx.bottom_menu('我')
        self.wx.userhome.main.click('我的资产')
        property.click('积分')
        driver.close()

    def test_redpack(self):
        '''
        我的资产->红包
        '''
        driver = self.driver
        property = self.wx.userhome.property
        self.wx.bottom_menu('我')
        self.wx.userhome.main.click('我的资产')
        property.click('红包')
        driver.close()

    def test_card_coupons(self):
        '''
        我的资产->卡券
        '''
        driver = self.driver
        property = self.wx.userhome.property
        self.wx.bottom_menu('我')
        self.wx.userhome.main.click('我的资产')
        property.click('卡券')
        driver.close()




